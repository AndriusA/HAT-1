# README #

### Hub-Of-All-Things - University of Warwick ###

* This repository is the central code repository for the Hub of All Things (University of Warwick) web application.

## How do I use the API? ###

* API documentation is available at: http://hat.onespace.media/api/v1/

### How do I get set up? ###

* TBC

### Contribution guidelines ###

* TBC

### Where can I see the live proof-of-concept? ###

* http://hat.onespace.media/

### Who do I talk to? ###

* daniel@onespacemedia.com (Daniel Samuels, Lead Developer)
* tom@onespacemedia.com (Thomas Rumbold, Head of Product)
* jamesfoley@onespacemedia.com (James Foley, Developer)
* x.ma@warwick.ac.uk (Xiao Ma, Project Lead @ University of Warwick)

### License

HAT database schema beta by [RCUK HAT Project Universities](http://www.hubofallthings.com/) is licensed under a [Creative Commons Attribution 4.0 International License](http://creativecommons.org/licenses/by/4.0/)