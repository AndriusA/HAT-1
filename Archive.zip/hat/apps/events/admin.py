from django.contrib import admin

from .models import Event, EventType, EventSensorDataCrossRef
# Register your models here.


class EventAdmin(admin.ModelAdmin):
    pass


class EventTypeAdmin(admin.ModelAdmin):
    pass

admin.site.register(Event, EventAdmin)
admin.site.register(EventType, EventTypeAdmin)
admin.site.register(EventSensorDataCrossRef)
