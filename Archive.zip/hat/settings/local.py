from .base import *

# Run in debug mode.
DEBUG = True

TEMPLATE_DEBUG = DEBUG

# Save media files to the user's Sites folder.
MEDIA_ROOT = os.path.expanduser("~/Site/hat/media")

STATIC_ROOT = os.path.expanduser("~/Site/hat/static")

# Use local server.
SITE_DOMAIN = "127.0.0.1"

# Disable the template cache for development.
TEMPLATE_LOADERS = (
    "django.template.loaders.filesystem.Loader",
    "django.template.loaders.app_directories.Loader",
)

# Separate database settings
DATABASES["default"]["HOST"] = "127.0.0.1"
DATABASES["default"]["NAME"] = "hat"
DATABASES["default"]["USER"] = os.getlogin()
DATABASES["default"]["PASSWORD"] = ""

# Mailtrip SMTP
# EMAIL_HOST = 'mailtrap.io'
# EMAIL_HOST_USER = ''
# EMAIL_HOST_PASSWORD = ''
# EMAIL_PORT = '2525'
# EMAIL_USE_TLS = True

RAVEN_CONFIG = {}

GRAPH_MODELS = {
    'all_applications': True,
    'group_models': True,
}